//@paystack/inline-js/index.d.ts
declare module '@paystack/inline-js';
