export const config = {
  reference: `${new Date().getTime()}`,
  email: 'user@example.com',
  amount: 10000,
  publicKey: 'pk_test_xdxfddole1992asdfghjkleetdfgxxxxxxx',
};
